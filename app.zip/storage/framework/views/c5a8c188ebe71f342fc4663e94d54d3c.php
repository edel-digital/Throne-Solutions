<!DOCTYPE html>
<head>
    
    

    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/src/main.tsx', 'resources/js/src/index.css']); ?>
</head>
 <body>
    <div id="root"></div>
  </body>
<?php /**PATH C:\Users\mwang\OneDrive\Desktop\On Adventure Africa\on-adventure-africa\resources\views/home.blade.php ENDPATH**/ ?>