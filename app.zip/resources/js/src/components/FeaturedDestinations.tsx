import React from 'react';

const Mission = () => {
  return (
    <div className="bg-white" style={{ fontFamily: 'Montserrat, sans-serif' }}>
      {/* Welcome Section */}
      <section className="text-center py-16 px-4 flex flex-col justify-center">
        <h4 className="text-sm text-black uppercase tracking-wide mb-2 text-brand">WELCOME TO</h4>
        <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">THRONE SOLUTIONS</h1>
        <p className="text-black max-w-2xl mx-auto">
          Throne Solutions Ltd is a dynamic consulting company specializing in leadership and business development. 
          With a history spanning six years, we have established ourselves as trusted advisors and partners to numerous 
          organizations seeking to unlock their full potential. Based in Nairobi, the thriving business hub of East Africa, 
          we are strategically positioned to cater to the growing needs of this vibrant and expanding population. Our deep-rooted 
          understanding of the local landscape, coupled with our extensive expertise, allows us to navigate the complexities of the regional market with ease.
          
        </p>
      </section>
    </div>
  );
};

export default Mission;
