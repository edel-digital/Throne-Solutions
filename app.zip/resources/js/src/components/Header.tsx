import React, { useState, useRef, useEffect } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [openSubDropdown, setOpenSubDropdown] = useState<string | null>(null);
  const [openThirdDropdown, setOpenThirdDropdown] = useState<string | null>(null);
  const location = useLocation();
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setOpenDropdown(null);
        setOpenSubDropdown(null);
        setOpenThirdDropdown(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About Us', path: '/about' },
    { 
      name: 'Services', 
      path: '/services',
      // dropdown: [
      //   { name: 'Web Development', path: '/web-dev' },
      //   { 
      //     name: 'Mobile Apps', 
      //     path: '/mobile-apps',
      //     subDropdown: [
      //       { name: 'iOS', path: '/ios' },
      //       { name: 'Android', path: '/android' }
      //     ]
      //   },
      //   { name: 'Cloud Solutions', path: '/cloud' }
      // ]
    },
    { name: 'Programs', path: '/programs' },
    // { name: 'Get Empowered', path: '/empower' },
    { name: 'Contact', path: '/contact' },
    { name: 'Book a session', path: '/book' }
    
  ];

  const toggleDropdown = (name: string) => {
    setOpenDropdown(openDropdown === name ? null : name);
    setOpenSubDropdown(null);
    setOpenThirdDropdown(null);
  };

  const toggleSubDropdown = (name: string) => {
    setOpenSubDropdown(openSubDropdown === name ? null : name);
    setOpenThirdDropdown(null);
  };

  const toggleThirdDropdown = (name: string) => {
    setOpenThirdDropdown(openThirdDropdown === name ? null : name);
  };

  const isActive = (path: string) => location.pathname === path;

  // Close mobile menu when route changes
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <header className="bg-white shadow-md py-3" ref={dropdownRef}>
      <div className="container mx-auto px-4 flex justify-between items-center">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <img 
            src="/images/logo-throne.png"
            alt="Throne Solutions Logo"
            className="h-16 w-auto"
          />
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-8">
          <nav className="flex items-center gap-6">
            {navLinks.map((link) => (
              <div key={link.name} className="relative group">
                {link.dropdown ? (
                  <div className="relative">
                    <button
                      onClick={() => toggleDropdown(link.name)}
                      className={`font-medium flex items-center gap-1 ${
                        isActive(link.path) ? 'text-brand' : 'text-gray-800'
                      } hover:text-brand transition-colors`}
                    >
                      {link.name}
                      <ChevronDown 
                        size={16} 
                        className={`transition-transform ${
                          openDropdown === link.name ? 'rotate-180' : ''
                        }`}
                      />
                    </button>
                    
                    {/* First Level Dropdown */}
                    {openDropdown === link.name && (
                      <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2 z-10">
                        {link.dropdown?.map((item) => (
                          <div key={item.name} className="relative">
                            {item.subDropdown ? (
                              <div>
                                <button
                                  onClick={() => toggleSubDropdown(item.name)}
                                  className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center justify-between"
                                >
                                  <span>{item.name}</span>
                                  <ChevronDown 
                                    size={14} 
                                    className={`ml-2 transition-transform ${
                                      openSubDropdown === item.name ? 'rotate-180' : ''
                                    }`}
                                  />
                                </button>
                                
                                {/* Second Level Dropdown */}
                                {openSubDropdown === item.name && (
                                  <div className="absolute left-full top-0 ml-1 w-48 bg-white rounded-md shadow-lg py-2 z-20">
                                    {item.subDropdown.map((subItem) => (
                                      <Link
                                        key={subItem.name}
                                        to={subItem.path}
                                        className="block px-4 py-2 hover:bg-gray-100"
                                        onClick={() => setOpenDropdown(null)}
                                      >
                                        {subItem.name}
                                      </Link>
                                    ))}
                                  </div>
                                )}
                              </div>
                            ) : (
                              <Link
                                to={item.path}
                                className="block px-4 py-2 hover:bg-gray-100"
                                onClick={() => setOpenDropdown(null)}
                              >
                                {item.name}
                              </Link>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <Link
                    to={link.path}
                    className={`font-medium hover:text-brand transition-colors ${
                      isActive(link.path) ? 'text-brand' : 'text-gray-800'
                    }`}
                  >
                    {link.name}
                  </Link>
                )}
              </div>
            ))}
          </nav>
          <div className="flex gap-4">
            {/* <button className="bg-brand text-white px-4 py-2 rounded-lg hover:bg-brand-dark transition whitespace-nowrap">
              Book Now
            </button> */}
            {/* <button className="text-gray-800 border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 transition whitespace-nowrap">
              Contact Us
            </button> */}
          </div>
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-gray-600 hover:text-brand transition-colors"
          onClick={() => setIsOpen(!isOpen)}
          aria-label={isOpen ? "Close menu" : "Open menu"}
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden bg-white shadow-lg">
          <div className="container mx-auto px-4 py-4 flex flex-col">
            {navLinks.map((link) => (
              <div key={link.name} className="border-b border-gray-100">
                {link.dropdown ? (
                  <div className="py-3">
                    <button
                      onClick={() => toggleDropdown(link.name)}
                      className={`w-full flex justify-between items-center font-medium ${
                        isActive(link.path) ? 'text-brand' : 'text-gray-800'
                      }`}
                    >
                      <span>{link.name}</span>
                      <ChevronDown 
                        size={18} 
                        className={`transition-transform ${
                          openDropdown === link.name ? 'rotate-180' : ''
                        }`}
                      />
                    </button>
                    
                    {/* Mobile Dropdown Content */}
                    {openDropdown === link.name && (
                      <div className="mt-2 ml-4 space-y-2">
                        {link.dropdown.map((item) => (
                          <div key={item.name} className="py-1">
                            {item.subDropdown ? (
                              <div>
                                <button
                                  onClick={() => toggleSubDropdown(item.name)}
                                  className="w-full flex justify-between items-center font-medium text-gray-700"
                                >
                                  <span>{item.name}</span>
                                  <ChevronDown 
                                    size={16} 
                                    className={`transition-transform ${
                                      openSubDropdown === item.name ? 'rotate-180' : ''
                                    }`}
                                  />
                                </button>
                                
                                {/* Mobile Sub-Dropdown Content */}
                                {openSubDropdown === item.name && (
                                  <div className="mt-1 ml-4 space-y-1">
                                    {item.subDropdown.map((subItem) => (
                                      <Link
                                        key={subItem.name}
                                        to={subItem.path}
                                        className="block py-1.5 text-gray-600 hover:text-brand"
                                        onClick={() => setIsOpen(false)}
                                      >
                                        {subItem.name}
                                      </Link>
                                    ))}
                                  </div>
                                )}
                              </div>
                            ) : (
                              <Link
                                to={item.path}
                                className="block py-1.5 text-gray-600 hover:text-brand"
                                onClick={() => setIsOpen(false)}
                              >
                                {item.name}
                              </Link>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <Link
                    to={link.path}
                    className={`block py-3 font-medium ${
                      isActive(link.path) ? 'text-brand' : 'text-gray-800'
                    }`}
                    onClick={() => setIsOpen(false)}
                  >
                    {link.name}
                  </Link>
                )}
              </div>
            ))}
            
            {/* Mobile Menu Buttons */}
            {/* <div className="mt-4 flex flex-col gap-3">
              <button 
                className="bg-brand text-white px-4 py-3 rounded-lg hover:bg-brand-dark transition"
                onClick={() => setIsOpen(false)}
              >
                Book Now
              </button>
              <button 
                className="text-gray-800 border border-gray-300 px-4 py-3 rounded-lg hover:bg-gray-50 transition"
                onClick={() => setIsOpen(false)}
              >
                Contact Us
              </button>
            </div> */}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;