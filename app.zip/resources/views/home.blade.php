<!DOCTYPE html>
<head>
    
    {{-- ... --}}

    @viteReactRefresh
    @vite(['resources/js/src/main.tsx', 'resources/js/src/index.css'])
</head>
 <body>
    <div id="root"></div>
  </body>
